<?php
	require '_core/init.php';
	$title = "Pileline";
	require '_includes/site-wide/header.php';
	require '_includes/_forms/email-entry-form.php';
	require '_includes/site-wide/footer.php';
?>